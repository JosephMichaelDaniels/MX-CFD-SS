# Integration Guide — Linking MetaConnex 3D Models to the Energy & CFD Module

**File:** `docs/integration-energy.md`  
**Applies to:** `apps/energy-cfd-simulation.html`

---

## Overview

The Energy & CFD module is designed to operate both standalone (demo mode) and as an integrated panel within the MetaConnex Three.js planning environment. This guide covers the complete integration path from clicking a building in the 3D canvas to receiving results back.

```
MetaConnex Canvas (Three.js)
        ↓  building click → Raycaster
        ↓  extract mesh.userData
        ↓  postMessage(buildingPayload)
Energy Module iframe
        ↓  populateInputs(data)
        ↓  runSimulation()
        ↓  populateResults(r)
        ↓  postMessage(resultsPayload) → back to canvas
```

---

## 1. Embedding the Module

Add the energy module as an iframe panel in your MetaConnex workspace layout:

```html
<!-- In your MetaConnex workspace HTML -->
<div id="energy-panel" class="side-panel" style="display:none;">
  <iframe
    id="energyFrame"
    src="/modules/energy-cfd-simulation.html"
    style="width:100%;height:100%;border:none;"
    allow="accelerometer; autoplay"
  ></iframe>
</div>
```

**Important:** Both documents must be served from the **same origin** (same domain + port) for `postMessage` security to work cleanly, or use explicit origin checking as shown below.

---

## 2. Building Data Schema

The module expects a `MCX_BUILDING_DATA` message with the following structure:

```javascript
// Full schema — all fields optional except type, floorArea, storeys
const buildingPayload = {
  type: 'MCX_BUILDING_DATA',         // Required — message identifier

  // ── GEOMETRY (from Three.js mesh userData) ──
  floorArea: 2400,                    // m² — single floor plate area
  storeys: 6,                         // integer
  floorHeight: 3.2,                   // m per floor
  glazingPct: 40,                     // 0–100 — window-to-wall ratio
  orientation: 'South',               // 'North'|'South'|'East'|'West'|'Mixed'
  buildingUse: 'Office',              // 'Office'|'Residential'|'Retail'|'Education'|'Healthcare'|'Mixed-Use'
  climate: 'UK Temperate',            // see climate zones in technical docs

  // ── MATERIALS (from product library or defaults) ──
  wallU: 0.18,                        // W/m²K — opaque wall U-value
  glazingU: 1.1,                      // W/m²K — glazing centre-pane
  glazingShgc: 0.35,                  // Solar Heat Gain Coefficient
  roofU: 0.13,                        // W/m²K
  floorU: 0.22,                       // W/m²K
  airPermeability: 3.0,               // m³/h·m² @ 50Pa
  thermalBridgePsi: 0.04,             // W/mK — linear thermal transmittance

  // ── HVAC ──
  heatingSystem: 'ASHP (COP 3.5)',    // see HVAC options below
  coolingSystem: 'VRF (EER 3.8)',
  ventilation: 'MVHR 85%',

  // ── SERVICES ──
  lightingLoad: 8,                    // W/m²
  equipmentLoad: 15,                  // W/m²
  occupancyDensity: 12,               // m² per person
  pvArea: 200,                        // m² — roof PV array

  // ── METADATA ──
  buildingId: 'BLD-001',             // MetaConnex building ID
  buildingName: 'Block A — Office',  // Display name
  siteRef: 'BOLTON-PHASE1',          // Site reference
};
```

### HVAC System Options
```javascript
// Heating
'ASHP (COP 3.5)'    // Air source heat pump
'GSHP (COP 4.2)'    // Ground source heat pump
'Gas Boiler (η 92%)' // Condensing gas boiler
'District Heat'      // District heating network
'Electric Panel'     // Direct electric

// Cooling
'VRF (EER 3.8)'         // Variable refrigerant flow
'Chilled Beam (EER 4.5)' // Active chilled beams
'Fan Coil (EER 3.2)'     // Fan coil units
'Passive Free Cool'      // Free cooling / natural ventilation

// Ventilation
'MVHR 85%'           // Mechanical ventilation + heat recovery
'CAV No Recovery'    // Constant air volume, no recovery
'VAV Demand Control' // Variable air volume
'Natural Ventilation' // Purely natural
```

---

## 3. Sending Data from the MetaConnex Canvas

### Step 1 — Detect Building Click

```javascript
// In your MetaConnex main canvas controller
import * as THREE from 'three';

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

canvas.addEventListener('click', (event) => {
  // Convert mouse position to normalised device coordinates
  const rect = canvas.getBoundingClientRect();
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(buildingMeshes, true);

  if (intersects.length > 0) {
    const mesh = intersects[0].object;
    handleBuildingClick(mesh);
  }
});
```

### Step 2 — Extract Geometry from Mesh

```javascript
function handleBuildingClick(mesh) {
  // Get stored userData (set when building was created from massing)
  const ud = mesh.userData;

  // Extract geometry from bounding box if userData not complete
  const bbox = new THREE.Box3().setFromObject(mesh);
  const size = bbox.getSize(new THREE.Vector3());

  // Estimate floor area from footprint (XZ plane)
  const estimatedFloorArea = ud.floorArea || Math.round(size.x * size.z);
  const estimatedStoreys = ud.storeys || Math.round(size.y / 3.2);

  // Build payload
  const payload = {
    type: 'MCX_BUILDING_DATA',
    buildingId: mesh.uuid,
    buildingName: ud.name || 'Selected Building',

    // Geometry
    floorArea: estimatedFloorArea,
    storeys: estimatedStoreys,
    floorHeight: ud.floorHeight || 3.2,
    glazingPct: ud.glazingPct || 35,
    orientation: ud.orientation || detectOrientation(mesh),

    // Use default materials if none specified
    wallU: ud.materials?.wall?.uValue || 0.26,
    glazingU: ud.materials?.glazing?.uValue || 1.6,
    glazingShgc: ud.materials?.glazing?.shgc || 0.40,
    roofU: ud.materials?.roof?.uValue || 0.18,
    floorU: ud.materials?.floor?.uValue || 0.22,
    airPermeability: ud.airPermeability || 5.0,

    // HVAC defaults
    heatingSystem: ud.hvac?.heating || 'ASHP (COP 3.5)',
    coolingSystem: ud.hvac?.cooling || 'VRF (EER 3.8)',
    ventilation: ud.hvac?.ventilation || 'MVHR 85%',

    // Services defaults
    lightingLoad: ud.services?.lighting || 8,
    equipmentLoad: ud.services?.equipment || 15,
    occupancyDensity: ud.services?.occupancy || 12,
    pvArea: ud.pvArea || 0,

    buildingUse: ud.useClass || 'Office',
    climate: detectClimate(siteLatitude, siteLongitude),
  };

  sendToEnergyModule(payload);
}
```

### Step 3 — Send to Energy Module

```javascript
function sendToEnergyModule(payload) {
  const frame = document.getElementById('energyFrame');
  if (!frame) return;

  // Show the energy panel
  document.getElementById('energy-panel').style.display = 'block';

  // Wait for iframe to be ready, then send
  frame.contentWindow.postMessage(payload, window.location.origin);
  // Use '*' if cross-origin (less secure): frame.contentWindow.postMessage(payload, '*');
}
```

---

## 4. Receiving Data in the Energy Module

Add this listener to `energy-cfd-simulation.html` (already included in the module):

```javascript
// In energy-cfd-simulation.html
window.addEventListener('message', (event) => {
  // Security: verify origin
  // if (event.origin !== 'https://app.metaconnex.earth') return;

  if (!event.data || event.data.type !== 'MCX_BUILDING_DATA') return;

  const data = event.data;

  // Populate all input fields
  populateFromMX(data);

  // Auto-trigger simulation
  buildBuilding();
  setTimeout(() => runSim(), 300);
});

function populateFromMX(data) {
  // Helper to safely set input value
  const set = (id, val) => {
    const el = document.getElementById(id);
    if (el && val !== undefined) el.value = val;
  };
  const setOpt = (id, val) => {
    const el = document.getElementById(id);
    if (!el || val === undefined) return;
    for (let i = 0; i < el.options.length; i++) {
      if (el.options[i].text.includes(val) || el.options[i].value === val) {
        el.selectedIndex = i; break;
      }
    }
  };

  set('floorArea', data.floorArea);
  set('storeys', data.storeys);
  set('floorH', data.floorHeight);
  set('glazPct', data.glazingPct);
  setOpt('orient', data.orientation);
  setOpt('bUse', data.buildingUse);
  setOpt('climate', data.climate);
  set('wallU', data.wallU);
  set('roofU', data.roofU);
  set('floorU', data.floorU);
  set('airPerm', data.airPermeability);
  set('psiVal', data.thermalBridgePsi);
  setOpt('heating', data.heatingSystem);
  setOpt('cooling', data.coolingSystem);
  setOpt('vent', data.ventilation);
  set('light', data.lightingLoad);
  set('equip', data.equipmentLoad);
  set('occ', data.occupancyDensity);
  set('pvArea', data.pvArea);

  // Update glazing material
  if (data.glazingU) { window._glazU = data.glazingU; }
  if (data.glazingShgc) { window._shgc = data.glazingShgc; }

  // Update building name for deck export
  const nameInput = document.getElementById('deckBuildingName');
  if (nameInput && data.buildingName) nameInput.value = data.buildingName;
}
```

---

## 5. Receiving Results Back in MetaConnex

After the simulation completes, the energy module can post results back:

```javascript
// Add to populateResults() in energy-cfd-simulation.html
function postResultsToParent(r) {
  if (!window.parent || window.parent === window) return;
  window.parent.postMessage({
    type: 'MCX_ENERGY_RESULTS',
    buildingId: window._currentBuildingId,
    epc: r.epc,
    eui: r.EUI,
    euiNet: r.EUInet,
    peakHeatKw: r.qHp,
    peakCoolKw: r.qCp,
    annualMwh: r.eTot / 1000,
    pvMwh: r.pvG / 1000,
    htTotal: r.htTot,
    crremKgCo2: +(r.EUI * 0.136).toFixed(2),
    compliance: {
      wallU: r.wallU <= 0.26,
      glazingU: r.glazU <= 1.6,
      roofU: r.roofU <= 0.18,
      airPerm: r.airPerm <= 5.0,
      eui: r.EUI <= 100,
      hvac: r.cop >= 3.0 || r.eer >= 3.5,
      renewables: r.pvG / r.eTot >= 0.1,
    }
  }, '*');
}
```

In your MetaConnex canvas, listen for this:

```javascript
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'MCX_ENERGY_RESULTS') return;
  const results = event.data;

  // Update the 3D building with EPC colour
  updateBuildingEPC(results.buildingId, results.epc, results.eui);

  // Update dashboard panel
  energyDashboard.update(results);

  // Store in building userData for future reference
  const mesh = getBuildingById(results.buildingId);
  if (mesh) {
    mesh.userData.energyResults = results;
    mesh.userData.epc = results.epc;
  }
});

function updateBuildingEPC(id, epc, eui) {
  const mesh = getBuildingById(id);
  if (!mesh) return;

  // Colour code building by EPC rating
  const epcColors = {
    'A+': 0x00FF88, 'A': 0x44DD77, 'B': 0x88CC44,
    'C': 0xCCBB22, 'D': 0xFFAA00, 'E': 0xFF7744, 'F': 0xFF4444
  };
  mesh.material.color.setHex(epcColors[epc] || 0xAAAAAA);
  mesh.material.emissive.setHex(0x000000);

  // Add EPC label above building
  addBuildingLabel(mesh, `EPC ${epc} · ${eui.toFixed(0)} kWh/m²`);
}
```

---

## 6. Storing Building Data in Three.js userData

When creating buildings from massing in MetaConnex, store all relevant data in `mesh.userData` so it can be retrieved on click:

```javascript
function createBuildingMesh(config) {
  const geometry = new THREE.BoxGeometry(
    config.width, config.height, config.depth
  );
  const material = new THREE.MeshStandardMaterial({ color: 0x1a3a5c });
  const mesh = new THREE.Mesh(geometry, material);

  // Store all building data in userData
  mesh.userData = {
    // Identity
    id: config.id,
    name: config.name,
    type: 'building',

    // Geometry
    floorArea: config.floorArea,
    storeys: config.storeys,
    floorHeight: config.floorHeight || 3.2,
    glazingPct: config.glazingPct || 35,
    orientation: config.orientation || 'South',
    useClass: config.useClass || 'Office',

    // Materials (from MetaConnex material library)
    materials: {
      wall: {
        id: config.wallProductId,
        name: config.wallProductName,
        uValue: config.wallUValue || 0.26,
        thickness: config.wallThickness || 300,
      },
      glazing: {
        id: config.glazingProductId,
        name: config.glazingProductName,
        uValue: config.glazingUValue || 1.6,
        shgc: config.glazingShgc || 0.40,
      },
      roof: { uValue: config.roofUValue || 0.18 },
      floor: { uValue: config.floorUValue || 0.22 },
    },

    // Services
    airPermeability: config.airPermeability || 5.0,
    thermalBridgePsi: config.thermalBridgePsi || 0.04,
    pvArea: config.pvArea || 0,
    hvac: {
      heating: config.heatingSystem || 'ASHP (COP 3.5)',
      cooling: config.coolingSystem || 'VRF (EER 3.8)',
      ventilation: config.ventilation || 'MVHR 85%',
    },
    services: {
      lighting: config.lightingLoad || 8,
      equipment: config.equipmentLoad || 15,
      occupancy: config.occupancyDensity || 12,
    },

    // Results (populated after energy sim)
    energyResults: null,
    epc: null,
  };

  return mesh;
}
```

---

## 7. Auto-Detecting Orientation

```javascript
function detectOrientation(mesh) {
  // Get world position and compare to site centroid
  const worldPos = new THREE.Vector3();
  mesh.getWorldPosition(worldPos);

  // Use building's primary face direction
  // (assumes building was placed with south face toward +Z)
  const forward = new THREE.Vector3(0, 0, 1);
  forward.applyQuaternion(mesh.quaternion);

  const angle = Math.atan2(forward.x, forward.z) * (180 / Math.PI);

  if (angle > -45 && angle <= 45) return 'South';
  if (angle > 45 && angle <= 135) return 'West';
  if (angle > 135 || angle <= -135) return 'North';
  return 'East';
}
```

---

## 8. Auto-Detecting Climate Zone from Site Location

```javascript
// Map UK grid reference or lat/lng to climate zone
function detectClimate(lat, lng) {
  if (!lat || !lng) return 'UK Temperate';

  // UK mainland
  if (lat >= 50 && lat <= 61 && lng >= -8 && lng <= 2) {
    if (lat > 57) return 'Nordic';    // Scotland Highlands
    return 'UK Temperate';
  }
  // Northern Europe
  if (lat > 54 && lng > 3) return 'Northern EU';
  // Mediterranean
  if (lat < 45) return 'Mediterranean';
  // Nordic
  if (lat > 60) return 'Nordic';

  return 'UK Temperate';
}
```

---

## 9. Complete Integration Example

```javascript
// MetaConnex — full integration example
class MetaConnexEnergyIntegration {
  constructor(canvas, camera, buildingMeshes) {
    this.canvas = canvas;
    this.camera = camera;
    this.buildings = buildingMeshes;
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    this.energyFrame = document.getElementById('energyFrame');

    this.canvas.addEventListener('click', this.onCanvasClick.bind(this));
    window.addEventListener('message', this.onMessage.bind(this));
  }

  onCanvasClick(event) {
    const rect = this.canvas.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.mouse, this.camera);

    const hits = this.raycaster.intersectObjects(this.buildings, true);
    if (hits.length > 0) {
      this.selectBuilding(hits[0].object);
    }
  }

  selectBuilding(mesh) {
    // Highlight selected
    this.buildings.forEach(b => b.material.emissive?.setHex(0x000000));
    mesh.material.emissive?.setHex(0x112233);

    // Build and send payload
    const payload = this.buildPayload(mesh);
    document.getElementById('energy-panel').style.display = 'block';
    this.energyFrame.contentWindow.postMessage(payload, window.location.origin);
  }

  buildPayload(mesh) {
    const ud = mesh.userData;
    const bbox = new THREE.Box3().setFromObject(mesh);
    const size = bbox.getSize(new THREE.Vector3());

    return {
      type: 'MCX_BUILDING_DATA',
      buildingId: mesh.uuid,
      buildingName: ud.name || 'Building',
      floorArea: ud.floorArea || Math.round(size.x * size.z),
      storeys: ud.storeys || Math.round(size.y / 3.2),
      floorHeight: ud.floorHeight || 3.2,
      glazingPct: ud.glazingPct || 35,
      orientation: detectOrientation(mesh),
      buildingUse: ud.useClass || 'Office',
      climate: detectClimate(window.MCX_SITE_LAT, window.MCX_SITE_LNG),
      wallU: ud.materials?.wall?.uValue || 0.26,
      glazingU: ud.materials?.glazing?.uValue || 1.6,
      glazingShgc: ud.materials?.glazing?.shgc || 0.40,
      roofU: ud.materials?.roof?.uValue || 0.18,
      floorU: ud.materials?.floor?.uValue || 0.22,
      airPermeability: ud.airPermeability || 5.0,
      thermalBridgePsi: ud.thermalBridgePsi || 0.04,
      heatingSystem: ud.hvac?.heating || 'ASHP (COP 3.5)',
      coolingSystem: ud.hvac?.cooling || 'VRF (EER 3.8)',
      ventilation: ud.hvac?.ventilation || 'MVHR 85%',
      lightingLoad: ud.services?.lighting || 8,
      equipmentLoad: ud.services?.equipment || 15,
      occupancyDensity: ud.services?.occupancy || 12,
      pvArea: ud.pvArea || 0,
    };
  }

  onMessage(event) {
    if (!event.data || event.data.type !== 'MCX_ENERGY_RESULTS') return;
    const r = event.data;
    const mesh = this.buildings.find(b => b.uuid === r.buildingId);
    if (mesh) {
      mesh.userData.energyResults = r;
      this.applyEPCColor(mesh, r.epc);
    }
  }

  applyEPCColor(mesh, epc) {
    const colors = {
      'A+': 0x00FF88, 'A': 0x44DD77, 'B': 0x88CC44,
      'C': 0xCCBB22, 'D': 0xFFAA00, 'E': 0xFF7744, 'F': 0xFF4444
    };
    mesh.material.color.setHex(colors[epc] || 0x888888);
  }
}

// Initialise
const integration = new MetaConnexEnergyIntegration(
  renderer.domElement, camera, buildingMeshes
);
```

---

## 10. JSON Schema Reference

See `integration/building-schema.json` for the full JSON Schema definition with types, constraints and defaults for all fields.
