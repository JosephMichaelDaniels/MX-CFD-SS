# Integration Guide — Linking MetaConnex 3D Models to the Social Impact Module

**File:** `docs/integration-social.md`  
**Applies to:** `apps/social-impact.html`

---

## Overview

The Social Impact module ingests site-level data from the MetaConnex massing environment. Unlike the energy module (which operates per-building), the social impact module operates at **site or phase level** — aggregating across all buildings in a masterplan to produce combined metrics for homes, employment, green space and carbon.

```
MetaConnex Site Context
        ↓  All buildings in phase → aggregate geometry
        ↓  Site boundary → green space extraction
        ↓  Construction programme → cost data
        ↓  postMessage(sitePayload)
Social Impact Module iframe
        ↓  populateSiteData(data)
        ↓  runCalc()
        ↓  renderTiers()
        ↓  postMessage(impactResults) → back to canvas
```

---

## 1. Embedding the Module

```html
<!-- In MetaConnex workspace HTML -->
<div id="impact-panel" class="full-panel" style="display:none;">
  <iframe
    id="impactFrame"
    src="/modules/social-impact.html"
    style="width:100%;height:100%;border:none;"
    allow="accelerometer"
  ></iframe>
</div>

<!-- Trigger button in MetaConnex UI -->
<button onclick="openImpactPanel()">
  Social Impact Analysis
</button>
```

---

## 2. Site Data Schema

The social impact module expects a `MCX_SITE_DATA` message:

```javascript
const sitePayload = {
  type: 'MCX_SITE_DATA',             // Required

  // ── PROJECT INFO ──
  projectName: 'Bolton Central Hub',
  localAuthority: 'Bolton MBC',
  region: 'North West',              // See region options
  developmentType: 'Mixed-Use',      // See type options

  // ── FROM MX MASSING (aggregated across all buildings) ──
  residentialGFA: 18000,             // m² — total residential floor area
  commercialGFA: 6400,               // m² — total commercial floor area
  greenSpaceArea: 3200,              // m² — total green/open space
  siteArea: 8500,                    // m² — total red line boundary
  batteryStorageMwh: 2.4,            // mWh — on-site storage capacity
  evChargingPoints: 42,              // count — total EV points
  renewablesOutputMwh: 340,          // mWh/yr — on-site generation

  // ── CONSTRUCTION ──
  constructionCostM: 85,             // £m — total programme cost
  embodiedCarbonKgCo2M2: 650,        // kgCO₂e/m² — from design/BQ
  floodInvestmentM: 1.2,             // £m — SuDS and mitigation
  habitatPreDev: 'Brownfield/Urban', // see habitat options
  habitatPostDev: 'Urban/Landscaped',

  // ── OPERATIONAL ──
  euiPreDev: 185,                    // kWh/m²/yr — existing buildings
  euiPostDev: 78,                    // kWh/m²/yr — new buildings
  incrementalTourists: 5000,         // visitors/yr — uplift from dev
  buildingUseClass: 'E (Commercial)',
  uknzbsRating: 'Gold',              // see rating options

  // ── METADATA ──
  siteId: 'BOLTON-CENTRAL-P1',
  phaseId: 'PHASE-1',
  siteLatitude: 53.578,
  siteLongitude: -2.429,
};
```

### Field Options Reference

```javascript
// Region
'North West' | 'Yorkshire' | 'Midlands' | 'London' |
'South East' | 'South West' | 'East' | 'North East' | 'Wales'

// Development Type
'Mixed-Use' | 'Residential' | 'Commercial' |
'Retail' | 'Education' | 'Healthcare'

// Habitat Pre-Development
'Brownfield/Urban' | 'Grassland Low Dist.' |
'Grassland Medium' | 'Woodland' | 'Arable'

// Habitat Post-Development
'Urban/Landscaped' | 'Species-rich Grassland' |
'Woodland' | 'Wildflower Meadow'

// UKNZBS Rating
'Platinum' | 'Gold' | 'Silver' | 'Bronze' | 'In Progress'

// Use Class (for business rates calculation)
'E (Commercial)' | 'C3 (Residential)' | 'F1 (Education)' |
'F2 (Community)' | 'B2 (Industrial)'
```

---

## 3. Aggregating Site Data from Multiple Buildings

The social impact module works at site level, so you need to sum across all buildings in a phase before sending:

```javascript
function aggregateSiteData(buildings, siteConfig) {
  // Sum residential and commercial GFA across all buildings
  const residentialGFA = buildings
    .filter(b => isResidential(b.userData.useClass))
    .reduce((sum, b) => sum + (b.userData.floorArea * b.userData.storeys), 0);

  const commercialGFA = buildings
    .filter(b => isCommercial(b.userData.useClass))
    .reduce((sum, b) => sum + (b.userData.floorArea * b.userData.storeys), 0);

  // Total PV area across all roofs
  const totalPvArea = buildings
    .reduce((sum, b) => sum + (b.userData.pvArea || 0), 0);

  // Weighted average EUI post-development
  const totalGFA = residentialGFA + commercialGFA;
  const weightedEUI = buildings.reduce((sum, b) => {
    const gfa = b.userData.floorArea * b.userData.storeys;
    const eui = b.userData.energyResults?.eui || estimateEUI(b.userData);
    return sum + (eui * gfa);
  }, 0) / (totalGFA || 1);

  // Weighted average embodied carbon
  const weightedEmbodied = buildings.reduce((sum, b) => {
    const gfa = b.userData.floorArea * b.userData.storeys;
    return sum + ((b.userData.embodiedCarbon || 650) * gfa);
  }, 0) / (totalGFA || 1);

  // Renewable output
  const pvOutput = totalPvArea * (siteConfig.solarIrradiance || 950) * 0.18 / 1000;
  const totalRenewables = pvOutput + (siteConfig.additionalRenewablesMwh || 0);

  return {
    type: 'MCX_SITE_DATA',
    projectName: siteConfig.name,
    localAuthority: siteConfig.authority,
    region: siteConfig.region,
    developmentType: detectMixedUse(residentialGFA, commercialGFA),

    residentialGFA: Math.round(residentialGFA),
    commercialGFA: Math.round(commercialGFA),
    greenSpaceArea: siteConfig.greenSpaceM2 || 0,
    siteArea: siteConfig.siteAreaM2,
    batteryStorageMwh: siteConfig.batteryMwh || 0,
    evChargingPoints: siteConfig.evPoints || 0,
    renewablesOutputMwh: Math.round(totalRenewables),

    constructionCostM: siteConfig.constructionCostM,
    embodiedCarbonKgCo2M2: Math.round(weightedEmbodied),
    floodInvestmentM: siteConfig.floodInvestM || 0,
    habitatPreDev: siteConfig.habitatPre || 'Brownfield/Urban',
    habitatPostDev: siteConfig.habitatPost || 'Urban/Landscaped',

    euiPreDev: siteConfig.euiPreDev || 185,
    euiPostDev: Math.round(weightedEUI),
    incrementalTourists: siteConfig.tourists || 0,
    uknzbsRating: detectUKNZBS(weightedEUI),
  };
}

function isResidential(useClass) {
  return ['Residential', 'C3', 'C1', 'C2'].some(c =>
    (useClass || '').includes(c)
  );
}

function isCommercial(useClass) {
  return ['Office', 'Retail', 'Commercial', 'E', 'B1', 'B2', 'Education', 'F'].some(c =>
    (useClass || '').includes(c)
  );
}

function detectMixedUse(resGFA, comGFA) {
  if (resGFA > 0 && comGFA > 0) return 'Mixed-Use';
  if (resGFA > comGFA) return 'Residential';
  return 'Commercial';
}

function detectUKNZBS(eui) {
  if (eui <= 30) return 'Platinum';
  if (eui <= 55) return 'Gold';
  if (eui <= 80) return 'Silver';
  if (eui <= 100) return 'Bronze';
  return 'In Progress';
}

function estimateEUI(userData) {
  // Fallback EUI estimate if energy sim not run yet
  const baseEUI = {
    'Office': 95, 'Residential': 80, 'Retail': 120,
    'Education': 85, 'Healthcare': 140, 'Mixed-Use': 90
  };
  return baseEUI[userData.useClass] || 95;
}
```

---

## 4. Sending Data to Social Impact Module

```javascript
function openImpactPanel() {
  const frame = document.getElementById('impactFrame');
  const panel = document.getElementById('impact-panel');

  panel.style.display = 'block';

  // Aggregate all buildings in current phase
  const currentPhaseBuildings = buildingMeshes.filter(b =>
    b.userData.phase === currentPhase
  );

  const payload = aggregateSiteData(currentPhaseBuildings, siteConfig);
  frame.contentWindow.postMessage(payload, window.location.origin);
}
```

---

## 5. Receiving Data in the Social Impact Module

Add this listener (or it can be added to the existing module):

```javascript
// In social-impact.html
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'MCX_SITE_DATA') return;
  populateSiteFromMX(event.data);
  setTimeout(() => runCalc(), 300);
});

function populateSiteFromMX(data) {
  const set = (id, val) => {
    const el = document.getElementById(id);
    if (el && val !== undefined) el.value = val;
  };
  const setOpt = (id, val) => {
    const el = document.getElementById(id);
    if (!el || val === undefined) return;
    for (let i = 0; i < el.options.length; i++) {
      if (el.options[i].text.includes(val) || el.options[i].value === val) {
        el.selectedIndex = i; break;
      }
    }
  };

  set('projName', data.projectName);
  set('localAuth', data.localAuthority);
  setOpt('region', data.region);
  setOpt('devType', data.developmentType);

  // Tier 1
  set('resGFA', data.residentialGFA);
  set('comGFA', data.commercialGFA);
  set('greenSpace', data.greenSpaceArea);
  set('siteArea', data.siteArea);
  set('battery', data.batteryStorageMwh);
  set('evPoints', data.evChargingPoints);
  set('renewables', data.renewablesOutputMwh);

  // Tier 2
  set('constCost', data.constructionCostM);
  set('embodiedC', data.embodiedCarbonKgCo2M2);
  set('floodInvest', data.floodInvestmentM);
  setOpt('habitatPre', data.habitatPreDev);
  setOpt('habitatPost', data.habitatPostDev);

  // Tier 3
  set('euiPre', data.euiPreDev);
  set('euiPost', data.euiPostDev);
  set('tourists', data.incrementalTourists);
  setOpt('useClass', data.buildingUseClass);
  setOpt('nzbs', data.uknzbsRating);

  // Deck name
  const deckInput = document.getElementById('deckName');
  if (deckInput && data.projectName) {
    deckInput.value = `${data.projectName} — Social Impact Report`;
  }
}
```

---

## 6. Posting Results Back

```javascript
// Called after runCalc() in social-impact.html
function postSocialResultsToParent(r) {
  if (!window.parent || window.parent === window) return;
  window.parent.postMessage({
    type: 'MCX_SOCIAL_RESULTS',
    siteId: window._siteId,
    overallScore: r.overallScore,
    tier1Score: r.t1Score,
    tier2Score: r.t2Score,
    tier3Score: r.t3Score,
    newHomes: r.newHomes,
    affordableHomes: r.affordableHomes,
    constructionJobs: r.constJobs,
    permanentFTE: r.jobsFTE,
    bngPct: r.bngPct,
    bngMet: r.bngPct >= 10,
    crremActual: r.crremActual,
    crremOnPathway: r.crremActual <= r.crremTarget2030,
    pcafScore: r.pcafScore,
    businessRatesM: r.businessRates,
    embodiedCarbon: r.becdCarbon,
    treeCount: r.trees,
    greenPerPerson: r.greenPerPerson,
  }, '*');
}
```

Listen for it in MetaConnex:

```javascript
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'MCX_SOCIAL_RESULTS') return;
  const r = event.data;

  // Update site overlay in canvas
  updateSiteOverlay(r.siteId, r.overallScore, r.bngMet, r.crremOnPathway);

  // Update planning dashboard
  planningDashboard.updateSocialKPIs(r);
});

function updateSiteOverlay(siteId, score, bngMet, crremOk) {
  const site = getSiteById(siteId);
  if (!site) return;

  // Colour site boundary by impact score
  const color = score >= 80 ? 0x00FF88 : score >= 65 ? 0xCCBB22 : 0xFF6644;
  site.boundaryMesh.material.color.setHex(color);

  // Add BNG indicator
  if (!bngMet) {
    site.addWarningMarker('BNG', 'Biodiversity Net Gain below 10% threshold');
  }

  // CRREM stranding risk flag
  if (!crremOk) {
    site.addWarningMarker('CRREM', 'Carbon intensity above 2030 CRREM pathway');
  }
}
```

---

## 7. Green Space Extraction from Massing

To automatically calculate green space from the MetaConnex site model:

```javascript
function extractGreenSpace(sitePolygon, buildingFootprints) {
  // Simple approach: site area minus building footprints
  // For full accuracy, use the landscape/open space layers

  const siteAreaM2 = computePolygonArea(sitePolygon);

  const builtArea = buildingFootprints.reduce((sum, fp) => {
    return sum + computePolygonArea(fp);
  }, 0);

  // Green space = site area minus built footprints
  // Adjust by hardstanding factor (typically 15% of site)
  const hardstanding = siteAreaM2 * 0.15;
  const greenSpace = Math.max(0, siteAreaM2 - builtArea - hardstanding);

  return Math.round(greenSpace);
}

function computePolygonArea(polygon) {
  // Shoelace formula for 2D polygon area
  let area = 0;
  const n = polygon.length;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    area += polygon[i].x * polygon[j].z;
    area -= polygon[j].x * polygon[i].z;
  }
  return Math.abs(area / 2);
}
```

---

## 8. Construction Cost Estimation from Massing

If no cost data is available from MetaConnex, estimate from GFA using RICS BCIS benchmarks:

```javascript
function estimateConstructionCost(buildings) {
  const RICS_COST_PER_M2 = {
    'Office': 2800,          // £/m² GIFA — RICS BCIS 2024
    'Residential': 2200,
    'Retail': 2100,
    'Education': 3100,
    'Healthcare': 4200,
    'Mixed-Use': 2600,
  };

  const totalCost = buildings.reduce((sum, b) => {
    const gfa = b.userData.floorArea * b.userData.storeys;
    const costPerM2 = RICS_COST_PER_M2[b.userData.useClass] || 2600;
    return sum + (gfa * costPerM2);
  }, 0);

  return +(totalCost / 1e6).toFixed(1); // £m
}
```

---

## 9. JSON Schema Reference

See `integration/social-schema.json` for the full JSON Schema with all field types, constraints and defaults.

---

## 10. Triggering Impact Analysis Automatically

For a seamless UX, trigger the social impact analysis automatically when the user opens the Impact panel, rather than requiring manual input:

```javascript
// In MetaConnex — when user clicks "Impact Analysis" tab
document.getElementById('impact-tab').addEventListener('click', () => {
  const frame = document.getElementById('impactFrame');
  const payload = aggregateSiteData(
    buildingMeshes.filter(b => b.userData.phase === currentPhase),
    currentSiteConfig
  );

  // If frame already loaded, send immediately
  if (frame.contentDocument?.readyState === 'complete') {
    frame.contentWindow.postMessage(payload, window.location.origin);
  } else {
    // Wait for load then send
    frame.addEventListener('load', () => {
      frame.contentWindow.postMessage(payload, window.location.origin);
    }, { once: true });
  }
});
```
