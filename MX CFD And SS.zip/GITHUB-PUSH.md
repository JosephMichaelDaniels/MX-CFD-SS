# How to Push to GitHub

The repository is fully committed locally. Follow these steps to push it to GitHub.

## Step 1 — Create the GitHub Repository

Go to **https://github.com/new** and create:
- **Repository name:** `building-performance-modules`
- **Description:** `MetaConnex Building Energy CFD & Social Impact Modules`
- **Visibility:** Private (recommended) or Public
- **⚠️ Do NOT initialise with README** — we already have one

## Step 2 — Push from Terminal

```bash
cd /home/claude/metaconnex-repo

# Rename branch to main
git branch -m master main

# Add your remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/building-performance-modules.git

# Push
git push -u origin main
```

## Step 3 — (Optional) Host on GitHub Pages

To make the HTML apps publicly accessible:

1. Go to **Repository Settings → Pages**
2. Source: **Deploy from branch**
3. Branch: **main** — Folder: **/ (root)**
4. Save

Apps will be live at:
- `https://YOUR_USERNAME.github.io/building-performance-modules/apps/energy-cfd-simulation.html`
- `https://YOUR_USERNAME.github.io/building-performance-modules/apps/social-impact.html`

## Files in This Commit

```
metaconnex-modules/
├── README.md                              Main documentation
├── apps/
│   ├── energy-cfd-simulation.html         Energy + CFD simulation tool (v3)
│   ├── social-impact.html                 Social & sustainability impact tool
│   └── energy-explainer.html              Public explainer deck
├── docs/
│   ├── energy-cfd-technical.md            Full calculation methodology
│   ├── social-impact-technical.md         All 24 metrics with formulas
│   ├── integration-energy.md              3D model → energy tool guide
│   └── integration-social.md             3D model → social tool guide
├── integration/
│   ├── mx-bridge.js                       postMessage bridge utility
│   ├── building-schema.json               Building data JSON schema
│   └── social-schema.json                 Site data JSON schema
└── GITHUB-PUSH.md                         This file
```
