# MetaConnex — Building Performance & Social Impact Modules

**MetaConnex™** is a digital masterplanning platform for local authorities, developers and investors. This repository contains two standalone simulation modules that integrate with the MetaConnex 3D planning environment to provide:

1. **Building Energy & CFD Simulation** — Full thermal, wind, solar and energy performance analysis with animated visualisations and engineering report export
2. **Social & Sustainability Impact** — Three-tier social impact scoring validated against Environment Act 2021, CRREM, PCAF, ONS and 11 named data sources

Both modules auto-populate from MetaConnex massing data and export animated presentation decks.

---

## Repository Structure

```
metaconnex-modules/
├── apps/
│   ├── energy-cfd-simulation.html     # Main energy + CFD tool (v3)
│   ├── social-impact.html             # Social & sustainability impact tool
│   └── energy-explainer.html          # Public-facing explainer deck
├── docs/
│   ├── energy-cfd-technical.md        # Technical documentation — energy tool
│   ├── social-impact-technical.md     # Technical documentation — social tool
│   ├── integration-energy.md          # 3D model integration guide — energy
│   └── integration-social.md          # 3D model integration guide — social
├── integration/
│   ├── mx-bridge.js                   # MetaConnex postMessage bridge
│   ├── building-schema.json           # Building data schema (JSON)
│   └── social-schema.json             # Social data schema (JSON)
└── README.md
```

---

## Quick Start

### Running Standalone (Demo Mode)
Open either HTML file directly in a browser. Both auto-load with demo data (Bolton Central Hub) and run a full simulation on load.

```bash
# Serve locally
npx serve apps/
# Or simply open in browser
open apps/energy-cfd-simulation.html
open apps/social-impact.html
```

### Embedding in MetaConnex Platform
See [`integration/mx-bridge.js`](integration/mx-bridge.js) and the integration guides in `/docs/`.

---

## Module Overview

### Energy & CFD Simulation
| Feature | Detail |
|---------|--------|
| Thermal Calculation | EN ISO 13790:2008 quasi-steady-state monthly method |
| CFD Wind Analysis | ASCE 7-22 pressure coefficients, velocity field |
| Solar Gain | EN ISO 13790 Eq. 43 with g-value and shading |
| Thermal Heatmap | Per-vertex U-value surface with animated heat arrows |
| Daylight | Sky dome photon simulation |
| HVAC Sizing | CIBSE Guide B — peak load × 1.25 margin |
| Annual Energy | 8,760-hr simulation, all end-uses metered |
| Compliance | 7 standards: Part L2A, EN ISO 13790, CIBSE TM54, ASHRAE 90.1, SAP 10.2, ASCE 7-22, ATTMA TS1 |
| Export | 10-slide animated deck with all simulation screenshots |

### Social & Sustainability Impact
| Feature | Detail |
|---------|--------|
| Tier 1 — Placemaking | Homes, BNG (Defra BM v4.0), green space (NPPF 9m²/p), EV, renewables |
| Tier 2 — Construction | ONS job multipliers, CITB, BECD embodied carbon, FWMA flood risk |
| Tier 3 — Legacy | CRREM 1.5°C pathways, PCAF scoring, VOA business rates, Homes England EDA |
| Scoring | Weighted three-tier impact score (0–100) |
| Data Sources | 11 live APIs and datasets, all named and cited |
| Export | 8-slide animated compliance deck with full report |

---

## Standards & Compliance

### Energy Module
- **EN ISO 13790:2008** — Energy performance calculation
- **CIBSE TM54** — Operational energy in use
- **CIBSE Guide A & B** — Environmental design, HVAC sizing
- **ASHRAE 90.1-2022** — Energy standard for buildings
- **UK Building Regulations Part L2A (2021)** — Non-domestic conservation
- **SAP 10.2** — Standard Assessment Procedure, EPC ratings
- **ASCE 7-22 / BS EN 1991-1-4** — Wind loads
- **ATTMA TS1:2010** — Air permeability testing
- **Future Homes Standard 2025** — Renewable energy requirements

### Social Module
- **Environment Act 2021** — Mandatory Biodiversity Net Gain (≥10%)
- **Defra Statutory BM v4.0 (2024)** — BNG calculation tool
- **NPPF 2024 §63** — Affordable housing (20% default)
- **NHS England / Mayor of London UGF** — 9m² green space per person
- **ONS Input-Output Tables 2021** — 3 FTE per £1m construction
- **CITB Levy Standard** — 2% apprentices
- **UKGBC BECD / RICS WLC 2nd Ed.** — Embodied carbon benchmarks
- **CRREM v2 (2023)** — Carbon Risk Real Estate Monitor, 1.5°C pathways
- **PCAF Standard** — Data quality scoring 1–5
- **VOA 2024/25** — Business rates multiplier 51.2p
- **Homes England EDA 2015** — 1 FTE per 20m² commercial

---

## Integration with MetaConnex 3D Platform

Both modules accept building data via `window.postMessage`. When a user clicks a building in the MetaConnex Three.js canvas, data is extracted from the mesh `userData` and passed to the module iframe:

```javascript
// In MetaConnex canvas — on building click
energyFrame.contentWindow.postMessage({
  type: 'MCX_BUILDING_DATA',
  floorArea: mesh.userData.floorArea,
  storeys: mesh.userData.storeys,
  wallU: mesh.userData.materials.wall.uValue,
  // ... (see integration/building-schema.json)
}, '*');
```

Full integration documentation: see [`docs/integration-energy.md`](docs/integration-energy.md) and [`docs/integration-social.md`](docs/integration-social.md).

---

## Tech Stack

| Component | Technology |
|-----------|-----------|
| 3D Visualisation | Three.js r128 |
| CFD Particles | Custom WebGL particle system (1,800 particles) |
| Solar Simulation | Photon ray-casting with glazing interaction |
| Thermal Mapping | Per-vertex colour geometry with U-value encoding |
| Calculation Engine | Pure JavaScript (no dependencies) |
| Export | `window.open()` with self-contained HTML |
| Fonts | Google Fonts — Cormorant Garamond, Space Mono, DM Sans, Bebas Neue |

---

## Licence

© MetaConnex Inc. All rights reserved. Proprietary software — not for redistribution without written permission.

---

## Contact

**Joseph Mitchell** — MetaConnex Inc.  
📧 info@metaconnex.earth  
🌐 [metaconnex.earth](https://metaconnex.earth)
