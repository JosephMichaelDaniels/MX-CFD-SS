/**
 * MetaConnex Module Bridge
 * Shared postMessage integration utility for Energy CFD and Social Impact modules
 *
 * Usage:
 *   import { MCXBridge } from './mx-bridge.js';
 *   const bridge = new MCXBridge('https://app.metaconnex.earth');
 *   bridge.sendBuildingToEnergy(mesh, { buildingName: 'Block A' });
 *   bridge.sendSiteToSocialImpact(buildings, siteConfig);
 *   bridge.onEnergyResults(results => updateCanvas(results));
 *   bridge.onSocialResults(results => updateOverlay(results));
 */

export class MCXBridge {
  /**
   * @param {string} allowedOrigin - Origin to accept messages from. Use '*' for dev.
   */
  constructor(allowedOrigin = '*') {
    this.allowedOrigin = allowedOrigin;
    this._energyCallbacks = [];
    this._socialCallbacks = [];
    this._energyFrame = null;
    this._socialFrame = null;

    window.addEventListener('message', this._onMessage.bind(this));
  }

  /** Set the energy module iframe element */
  setEnergyFrame(frame) { this._energyFrame = frame; return this; }

  /** Set the social impact module iframe element */
  setSocialFrame(frame) { this._socialFrame = frame; return this; }

  // ─────────────────────────────────────────────────
  // ENERGY MODULE
  // ─────────────────────────────────────────────────

  /**
   * Send a single building mesh to the Energy CFD module
   * @param {THREE.Mesh} mesh - Building mesh with populated userData
   * @param {Object} overrides - Override any auto-detected values
   */
  sendBuildingToEnergy(mesh, overrides = {}) {
    if (!this._energyFrame) {
      console.warn('[MCXBridge] energyFrame not set. Call setEnergyFrame() first.');
      return;
    }
    const payload = { ...this._extractBuildingData(mesh), ...overrides };
    this._send(this._energyFrame, payload);
  }

  /**
   * Send raw building data object to Energy module
   * @param {Object} data - Building data conforming to MCX_BUILDING_DATA schema
   */
  sendBuildingData(data) {
    if (!this._energyFrame) return;
    this._send(this._energyFrame, { type: 'MCX_BUILDING_DATA', ...data });
  }

  /**
   * Register callback for energy results
   * @param {Function} cb - Called with MCX_ENERGY_RESULTS payload
   */
  onEnergyResults(cb) { this._energyCallbacks.push(cb); return this; }

  // ─────────────────────────────────────────────────
  // SOCIAL IMPACT MODULE
  // ─────────────────────────────────────────────────

  /**
   * Aggregate site data from multiple buildings and send to Social Impact module
   * @param {THREE.Mesh[]} buildings - Array of building meshes in the phase
   * @param {Object} siteConfig - Site-level configuration (see schema)
   */
  sendSiteToSocialImpact(buildings, siteConfig = {}) {
    if (!this._socialFrame) {
      console.warn('[MCXBridge] socialFrame not set. Call setSocialFrame() first.');
      return;
    }
    const payload = this._aggregateSiteData(buildings, siteConfig);
    this._send(this._socialFrame, payload);
  }

  /**
   * Send raw site data object to Social Impact module
   * @param {Object} data - Site data conforming to MCX_SITE_DATA schema
   */
  sendSiteData(data) {
    if (!this._socialFrame) return;
    this._send(this._socialFrame, { type: 'MCX_SITE_DATA', ...data });
  }

  /**
   * Register callback for social impact results
   * @param {Function} cb - Called with MCX_SOCIAL_RESULTS payload
   */
  onSocialResults(cb) { this._socialCallbacks.push(cb); return this; }

  // ─────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────

  _send(frame, payload) {
    try {
      const target = this.allowedOrigin === '*' ? '*' : this.allowedOrigin;
      frame.contentWindow.postMessage(payload, target);
    } catch (e) {
      console.error('[MCXBridge] postMessage failed:', e);
    }
  }

  _onMessage(event) {
    if (this.allowedOrigin !== '*' && event.origin !== this.allowedOrigin) return;
    if (!event.data?.type) return;

    if (event.data.type === 'MCX_ENERGY_RESULTS') {
      this._energyCallbacks.forEach(cb => cb(event.data));
    } else if (event.data.type === 'MCX_SOCIAL_RESULTS') {
      this._socialCallbacks.forEach(cb => cb(event.data));
    }
  }

  _extractBuildingData(mesh) {
    const ud = mesh.userData || {};
    const bbox = new THREE.Box3().setFromObject(mesh);
    const size = bbox.getSize(new THREE.Vector3());

    return {
      type: 'MCX_BUILDING_DATA',
      buildingId: mesh.uuid,
      buildingName: ud.name || 'Building',
      floorArea: ud.floorArea || Math.round(size.x * size.z),
      storeys: ud.storeys || Math.max(1, Math.round(size.y / 3.2)),
      floorHeight: ud.floorHeight || 3.2,
      glazingPct: ud.glazingPct || 35,
      orientation: ud.orientation || MCXBridge.detectOrientation(mesh),
      buildingUse: ud.useClass || 'Office',
      climate: ud.climate || 'UK Temperate',
      wallU: ud.materials?.wall?.uValue || 0.26,
      glazingU: ud.materials?.glazing?.uValue || 1.6,
      glazingShgc: ud.materials?.glazing?.shgc || 0.40,
      roofU: ud.materials?.roof?.uValue || 0.18,
      floorU: ud.materials?.floor?.uValue || 0.22,
      airPermeability: ud.airPermeability || 5.0,
      thermalBridgePsi: ud.thermalBridgePsi || 0.04,
      heatingSystem: ud.hvac?.heating || 'ASHP (COP 3.5)',
      coolingSystem: ud.hvac?.cooling || 'VRF (EER 3.8)',
      ventilation: ud.hvac?.ventilation || 'MVHR 85%',
      lightingLoad: ud.services?.lighting || 8,
      equipmentLoad: ud.services?.equipment || 15,
      occupancyDensity: ud.services?.occupancy || 12,
      pvArea: ud.pvArea || 0,
    };
  }

  _aggregateSiteData(buildings, cfg = {}) {
    const res = buildings.filter(b => MCXBridge.isResidential(b.userData?.useClass));
    const com = buildings.filter(b => MCXBridge.isCommercial(b.userData?.useClass));

    const resGFA = res.reduce((s, b) => s + (b.userData.floorArea || 0) * (b.userData.storeys || 1), 0);
    const comGFA = com.reduce((s, b) => s + (b.userData.floorArea || 0) * (b.userData.storeys || 1), 0);
    const totalGFA = resGFA + comGFA || 1;

    const weightedEUI = buildings.reduce((s, b) => {
      const gfa = (b.userData.floorArea || 0) * (b.userData.storeys || 1);
      const eui = b.userData.energyResults?.eui || MCXBridge.estimateEUI(b.userData?.useClass);
      return s + eui * gfa;
    }, 0) / totalGFA;

    const weightedEC = buildings.reduce((s, b) => {
      const gfa = (b.userData.floorArea || 0) * (b.userData.storeys || 1);
      return s + (b.userData.embodiedCarbon || 650) * gfa;
    }, 0) / totalGFA;

    const totalPvArea = buildings.reduce((s, b) => s + (b.userData.pvArea || 0), 0);
    const pvMwh = totalPvArea * (cfg.solarIrradiance || 950) * 0.18 / 1000;

    return {
      type: 'MCX_SITE_DATA',
      projectName: cfg.name || cfg.projectName || 'Development Site',
      localAuthority: cfg.authority || cfg.localAuthority || '',
      region: cfg.region || 'UK',
      developmentType: MCXBridge.detectDevType(resGFA, comGFA),
      residentialGFA: Math.round(resGFA),
      commercialGFA: Math.round(comGFA),
      greenSpaceArea: cfg.greenSpaceM2 || 0,
      siteArea: cfg.siteAreaM2 || 0,
      batteryStorageMwh: cfg.batteryMwh || 0,
      evChargingPoints: cfg.evPoints || 0,
      renewablesOutputMwh: Math.round(pvMwh + (cfg.additionalRenewablesMwh || 0)),
      constructionCostM: cfg.constructionCostM || MCXBridge.estimateCost(buildings),
      embodiedCarbonKgCo2M2: Math.round(weightedEC),
      floodInvestmentM: cfg.floodInvestM || 0,
      habitatPreDev: cfg.habitatPre || 'Brownfield/Urban',
      habitatPostDev: cfg.habitatPost || 'Urban/Landscaped',
      euiPreDev: cfg.euiPreDev || 185,
      euiPostDev: Math.round(weightedEUI),
      incrementalTourists: cfg.tourists || 0,
      buildingUseClass: cfg.useClass || 'E (Commercial)',
      uknzbsRating: MCXBridge.inferUKNZBS(weightedEUI),
    };
  }

  // ─────────────────────────────────────────────────
  // STATIC HELPERS
  // ─────────────────────────────────────────────────

  static isResidential(useClass = '') {
    return /residential|C3|C2|C1|dwelling|apartment|flat/i.test(useClass);
  }

  static isCommercial(useClass = '') {
    return /office|retail|commercial|E\b|B1|B2|education|healthcare|F\b/i.test(useClass);
  }

  static detectDevType(resGFA, comGFA) {
    if (resGFA > 0 && comGFA > 0) return 'Mixed-Use';
    if (resGFA >= comGFA) return 'Residential';
    return 'Commercial';
  }

  static estimateEUI(useClass = '') {
    const defaults = {
      Office: 95, Residential: 80, Retail: 120,
      Education: 85, Healthcare: 140
    };
    for (const [k, v] of Object.entries(defaults)) {
      if (useClass.includes(k)) return v;
    }
    return 95;
  }

  static inferUKNZBS(eui) {
    if (eui <= 30) return 'Platinum';
    if (eui <= 55) return 'Gold';
    if (eui <= 80) return 'Silver';
    if (eui <= 100) return 'Bronze';
    return 'In Progress';
  }

  static estimateCost(buildings) {
    const RICS = { Office: 2800, Residential: 2200, Retail: 2100, Education: 3100 };
    const total = buildings.reduce((s, b) => {
      const gfa = (b.userData.floorArea || 0) * (b.userData.storeys || 1);
      const rate = RICS[b.userData.useClass] || 2600;
      return s + gfa * rate;
    }, 0);
    return +(total / 1e6).toFixed(1);
  }

  static detectOrientation(mesh) {
    const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(mesh.quaternion);
    const angle = Math.atan2(forward.x, forward.z) * (180 / Math.PI);
    if (angle > -45 && angle <= 45) return 'South';
    if (angle > 45 && angle <= 135) return 'West';
    if (angle > 135 || angle <= -135) return 'North';
    return 'East';
  }
}

// ─────────────────────────────────────────────────
// MODULE RECEIVER (add to energy/social HTML files)
// ─────────────────────────────────────────────────

/**
 * Add this to energy-cfd-simulation.html to receive building data
 */
export function initEnergyReceiver(populateFn, runFn) {
  window.addEventListener('message', (event) => {
    if (!event.data || event.data.type !== 'MCX_BUILDING_DATA') return;
    try {
      populateFn(event.data);
      setTimeout(() => runFn(), 300);
    } catch (e) {
      console.error('[MCXBridge] Energy receiver error:', e);
    }
  });
}

/**
 * Add this to social-impact.html to receive site data
 */
export function initSocialReceiver(populateFn, runFn) {
  window.addEventListener('message', (event) => {
    if (!event.data || event.data.type !== 'MCX_SITE_DATA') return;
    try {
      populateFn(event.data);
      setTimeout(() => runFn(), 300);
    } catch (e) {
      console.error('[MCXBridge] Social receiver error:', e);
    }
  });
}
